#ifndef CONVERTERS_H
#define CONVERTERS_H
#include <string>
#include <vector>

using namespace std;

vector<string> tokenizeString (string input, string delimiter);
int *xyer(int *xys, vector<string> fivelines);
int rainer(string ap, string acc);
string lmher(int amount);


#endif